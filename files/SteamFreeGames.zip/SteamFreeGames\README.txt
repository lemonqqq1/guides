Steam Free Games — сам забирает бесплатные игры Steam (скидка 100%, остаются навсегда)

Нужен Python 3 (python.org, галочка "Add to PATH") и команда в cmd:  pip install requests

1. Зайди в store.steampowered.com в Chrome.
2. F12 -> Application -> Cookies -> https://store.steampowered.com
3. Скопируй значение steamLoginSecure в config.json вместо ВСТАВЬ_СЮДА_COOKIE.
4. Запусти run.bat, результат смотри в claim.log.
5. Автозапуск раз в день: Планировщик заданий -> Создать простую задачу -> ежедневно -> запуск run.bat.

Всё работает только на твоём ПК, cookie никуда не отправляется (только на steampowered.com).
Никому не показывай config.json. Cookie живёт несколько недель, потом вставь новый.
include_dlc: true — и бесплатные DLC, false — только игры.
