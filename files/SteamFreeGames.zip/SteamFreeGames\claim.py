"""Ежедневно ищет в Steam игры со скидкой 100% (free to keep) и добавляет их на аккаунт.

Нужен cookie steamLoginSecure из браузера (см. README.txt), он лежит в config.json.
"""
import json
import re
import secrets
import sys
import time
from datetime import datetime
from pathlib import Path

import requests

BASE = Path(__file__).resolve().parent
CONFIG = BASE / "config.json"
STATE = BASE / "claimed.json"
LOG = BASE / "claim.log"

SEARCH_URL = "https://store.steampowered.com/search/results/"
CLAIM_URL = "https://store.steampowered.com/freelicense/addfreelicense/"
USERDATA_URL = "https://store.steampowered.com/dynamicstore/userdata/"


def log(msg):
    line = f"{datetime.now():%Y-%m-%d %H:%M:%S}  {msg}"
    print(line)
    with LOG.open("a", encoding="utf-8") as f:
        f.write(line + "\n")


def load_json(path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def make_session(cookie):
    s = requests.Session()
    s.headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/130 Safari/537.36"
    sessionid = secrets.token_hex(12)
    for name, value in {
        "steamLoginSecure": cookie,
        "sessionid": sessionid,
        "birthtime": "631152001",
        "wants_mature_content": "1",
        "Steam_Language": "english",
    }.items():
        s.cookies.set(name, value, domain="store.steampowered.com")
    s.sessionid = sessionid
    return s


def owned_apps(s):
    """Множество appid на аккаунте; None, если cookie протух."""
    data = s.get(USERDATA_URL, timeout=30).json()
    apps = data.get("rgOwnedApps") or []
    if not apps and not data.get("rgOwnedPackages"):
        return None
    return set(apps)


def find_free_apps(s, include_dlc):
    params = {"maxprice": "free", "specials": "1", "infinite": "1", "json": "1", "count": "100"}
    if not include_dlc:
        params["category1"] = "998"  # только игры
    apps, start = {}, 0
    while True:
        params["start"] = str(start)
        data = s.get(SEARCH_URL, params=params, timeout=30).json()
        html = data.get("results_html", "")
        for m in re.finditer(r'data-ds-appid="(\d+)".*?class="title">(.*?)<', html, re.S):
            apps[int(m.group(1))] = m.group(2)
        start += 100
        if start >= int(data.get("total_count") or 0):
            return apps


def free_subids(s, appid):
    """subid бесплатных лицензий с бейджем «Free to keep» на странице игры."""
    html = s.get(f"https://store.steampowered.com/app/{appid}/", params={"l": "english"}, timeout=30).text
    subids = []
    for block in re.split(r'<div class="game_area_purchase_game', html)[1:]:
        if "freelicense/addfreelicense" in block and "Free to keep" in block:
            m = re.search(r'name="subid" value="(\d+)"', block)
            if m:
                subids.append(int(m.group(1)))
    return subids


def claim(s, subid):
    r = s.post(CLAIM_URL, data={"action": "add_to_cart", "sessionid": s.sessionid, "subid": subid,
                                "snr": "1_5_9__403", "originating_snr": ""}, timeout=30)
    return r.status_code


def main():
    cfg = load_json(CONFIG, {})
    cookie = cfg.get("steamLoginSecure", "").strip()
    if not cookie or cookie.startswith("ВСТАВЬ"):
        log("ОШИБКА: в config.json нет steamLoginSecure, см. README.txt")
        return 1

    s = make_session(cookie)
    owned = owned_apps(s)
    if owned is None:
        log("ОШИБКА: cookie steamLoginSecure протух — обнови его в config.json (README.txt)")
        return 1

    state = load_json(STATE, {})
    free = find_free_apps(s, cfg.get("include_dlc", True))
    log(f"Найдено со скидкой 100%: {len(free)}, на аккаунте уже {len(owned)} приложений")

    added = []
    for appid, title in free.items():
        if appid in owned:
            continue
        for subid in free_subids(s, appid):
            if str(subid) in state:
                continue
            code = claim(s, subid)
            state[str(subid)] = {"appid": appid, "title": title, "date": f"{datetime.now():%Y-%m-%d}", "http": code}
            log(f"Забрал: {title} (app {appid}, sub {subid}) — HTTP {code}")
            added.append((appid, title))
            time.sleep(3)

    STATE.write_text(json.dumps(state, ensure_ascii=False, indent=1), encoding="utf-8")

    if added:
        time.sleep(5)
        owned = owned_apps(s) or set()
        for appid, title in added:
            log(f"  {'OK на аккаунте' if appid in owned else 'НЕ появилось (возможно, нужна базовая игра)'}: {title}")
    else:
        log("Новых бесплатных игр нет")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:  # чтобы ошибка попала в лог при запуске из планировщика
        log(f"ОШИБКА: {e!r}")
        sys.exit(1)
