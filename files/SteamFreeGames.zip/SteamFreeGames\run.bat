@echo off
cd /d "%~dp0"
python claim.py
